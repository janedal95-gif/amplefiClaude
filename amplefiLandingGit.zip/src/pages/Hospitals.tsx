import React from 'react';
import HospitalsPage from '@/components/HospitalsPage';

const Hospitals: React.FC = () => {
  return <HospitalsPage />;
};

export default Hospitals;