import React from 'react';
import { ArrowRight } from 'lucide-react';

const phases = [
  { phase: "Phase 1", title: "ADT Foundation", items: ["Real-time ADT integration", "Basic flow visibility", "Discharge readiness signals"] },
  { phase: "Phase 2", title: "Flow Intelligence", items: ["Bed management agents", "Bottleneck detection", "Handoff tracking"] },
  { phase: "Phase 3", title: "Clinical Risk", items: ["AKI/Sepsis early warning", "Deterioration detection", "Proactive intervention prompts"] },
  { phase: "Phase 4", title: "Full Operating System", items: ["Cross-department coordination", "Predictive capacity planning", "Continuous optimization"] }
];

const MVPSection: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            MVP Quick Start
          </h2>
          <p className="text-xl text-muted-foreground">
            Start with ADT. Prove value fast. Expand from there.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {phases.map((p, index) => (
            <div key={index} className="bg-card p-6 border border-border relative">
              <span className="text-sm font-semibold text-accent uppercase tracking-wider">{p.phase}</span>
              <h3 className="text-xl font-bold text-foreground mt-2 mb-4">{p.title}</h3>
              <ul className="space-y-2">
                {p.items.map((item, i) => (
                  <li key={i} className="text-muted-foreground text-sm flex items-start gap-2">
                    <ArrowRight className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MVPSection;
