import React from 'react';
import { X, Check } from 'lucide-react';

const comparisons = [
  { aspect: "Architecture", cc: "Centralized control room", amplefi: "Distributed to frontline" },
  { aspect: "Approach", cc: "Reactive monitoring", amplefi: "Preemptive intervention" },
  { aspect: "Interface", cc: "Dashboards and displays", amplefi: "Intelligent agents" },
  { aspect: "Action", cc: "Escalate to supervisors", amplefi: "Empower frontline staff" },
  { aspect: "Cost", cc: "High infrastructure investment", amplefi: "Minimal tech footprint" },
  { aspect: "Outcome", cc: "Better visibility", amplefi: "Better outcomes" }
];

const ComparisonSection: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Why Not Command Centers?
          </h2>
          <p className="text-xl text-primary-foreground">
            Command centers are expensive monuments to visibility. We build capability where the work happens.
          </p>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-4 pr-4 text-primary-foreground font-medium w-1/6"></th>
                <th className="text-left py-4 px-4 text-primary-foreground font-medium w-5/12">Command Centers</th>
                <th className="text-left py-4 pl-4 text-primary-foreground font-medium w-5/12">Amplefi Approach</th>
              </tr>
            </thead>
            <tbody>
              {comparisons.map((row, index) => (
                <tr key={index} className="border-b border-border">
                  <td className="py-5 pr-4 text-primary-foreground font-medium align-top">{row.aspect}</td>
                  <td className="py-5 px-4 text-primary-foreground align-top">
                    <div className="flex items-start gap-3">
                      <X className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                      <span>{row.cc}</span>
                    </div>
                  </td>
                  <td className="py-5 pl-4 text-primary-foreground align-top">
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                      <span>{row.amplefi}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;
