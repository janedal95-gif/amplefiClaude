import React from 'react';

const HospitalCTA: React.FC = () => {
  const scrollToContact = () => {
    document.getElementById('footer')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-24 md:py-32 bg-accent text-accent-foreground">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-8">
          Ready to see what's coming?
        </h2>
        <p className="text-xl text-accent-foreground mb-12 max-w-2xl mx-auto">
          Let's walk through your current operations and show you exactly where foresight would make the biggest difference.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button 
            onClick={scrollToContact}
            className="bg-primary text-primary-foreground px-10 py-5 text-lg font-semibold transition-colors"
          >
            Book a Walkthrough
          </button>
          <button 
            onClick={scrollToContact}
            className="border-2 border-secondary text-accent px-10 py-5 text-lg font-semibold transition-colors"
          >
            Start a 30-Day Diagnostic
          </button>
        </div>
      </div>
    </section>
  );
};

export default HospitalCTA;
