import React from 'react';

const stats = [
  { value: "32%", label: "Reduction in discharge delays" },
  { value: "4.2h", label: "Earlier risk detection" },
  { value: "28%", label: "Decrease in ED boarding time" },
  { value: "41%", label: "Fewer escalations to leadership" }
];

const HospitalStats: React.FC = () => {
  return (
    <section className="py-20 bg-background border-y border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            Hospital Results
          </p>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl md:text-5xl lg:text-6xl font-bold text-accent mb-2">
                {stat.value}
              </div>
              <p className="text-muted-foreground text-sm md:text-base">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HospitalStats;
