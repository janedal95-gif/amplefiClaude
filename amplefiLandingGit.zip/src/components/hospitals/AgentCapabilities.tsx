import React from 'react';
import { Activity, BedDouble, Clock, AlertCircle, ListChecks, TrendingUp } from 'lucide-react';

const capabilities = [
  { icon: Activity, title: "Detect Flow Problems", desc: "Real-time identification of emerging bottlenecks before they cascade" },
  { icon: BedDouble, title: "Identify Ready-to-Move Patients", desc: "Surface patients who are discharge-ready but stuck in the system" },
  { icon: Clock, title: "Highlight Delays", desc: "Flag handoff delays, pending orders, and waiting tasks" },
  { icon: AlertCircle, title: "Flag Potential Complications", desc: "Early warning for AKI, sepsis, falls, and deterioration" },
  { icon: ListChecks, title: "Prompt Next Actions", desc: "Specific, actionable recommendations delivered to the right person" },
  { icon: TrendingUp, title: "Track Intervention Impact", desc: "Measure what works and continuously improve protocols" }
];

const AgentCapabilities: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            What Our Agents Do
          </h2>
          <p className="text-xl text-muted-foreground">
            AI that works alongside your teams—not instead of them.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((cap, index) => (
            <div key={index} className="group border-2 border-border p-8 hover:border-accent transition-colors bg-card">
              <cap.icon className="w-10 h-10 text-muted-foreground group-hover:text-accent transition-colors mb-4" strokeWidth={1.5} />
              <h3 className="text-xl font-bold text-foreground mb-2">{cap.title}</h3>
              <p className="text-muted-foreground">{cap.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AgentCapabilities;
