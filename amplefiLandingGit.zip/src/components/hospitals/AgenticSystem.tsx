import React from 'react';
import { Eye, Shield, Zap } from 'lucide-react';

const pillars = [
  {
    icon: Eye,
    title: "Forward View of Patient Flow",
    desc: "ADT data transformed into actionable foresight. See discharge readiness, bed availability, and flow bottlenecks before they become crises."
  },
  {
    icon: Shield,
    title: "Preemptive Clinical Protocols",
    desc: "AI agents that detect early risk signals—AKI, sepsis, deterioration—and prompt teams with specific next actions while intervention is still possible."
  },
  {
    icon: Zap,
    title: "Distributed Action Authority",
    desc: "Empower charge nurses, bed managers, and unit leaders to act on what they see. Clear escalation paths. Fast decisions. Real accountability."
  }
];

const AgenticSystem: React.FC = () => {
  return (
    <section id="agentic-system" className="py-24 md:py-32 bg-accent text-accent-foreground">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
            The Agentic Hospital Operating System
          </h2>
          <p className="text-xl text-accent-foreground max-w-3xl mx-auto">
            Three pillars that transform hospital operations from reactive to preemptive.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => (
            <div 
              key={index} 
              className="bg-[hsl(var(--accent-foreground))/0.05] border border-[hsl(var(--accent-foreground))/0.1] p-8 md:p-10 hover:bg-[hsl(var(--accent-foreground))/0.1] transition-colors"
            >
              <pillar.icon className="w-12 h-12 mb-6 text-accent-foreground" strokeWidth={1.5} />
              <h3 className="text-2xl font-bold mb-4">{pillar.title}</h3>
              <p className="text-accent-foreground leading-relaxed">{pillar.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AgenticSystem;
