import React from 'react';
import { AlertTriangle } from 'lucide-react';

const frictions = [
  { title: "Bed Block", desc: "Patients ready to leave, stuck waiting. Beds needed, sitting empty." },
  { title: "Discharge Delays", desc: "Paperwork, transport, pharmacy—each handoff a potential black hole." },
  { title: "OR Drift", desc: "Surgeries that start late cascade into chaos by afternoon." },
  { title: "ED Boarding", desc: "Emergency patients waiting hours for beds that exist somewhere." },
  { title: "Missed Handoffs", desc: "Critical information lost in shift changes and department transitions." },
  { title: "Predictable Complications", desc: "AKI, sepsis, falls—problems that announce themselves before they arrive." },
  { title: "Staff Burnout", desc: "Your best people exhausted from fighting fires that shouldn't exist." }
];

const HospitalReality: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            The Hospital Reality
          </h2>
          <p className="text-xl text-muted-foreground">
            You know these problems. You live them every day. The question isn't whether they exist—it's whether you can see them coming.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {frictions.map((friction, index) => (
            <div key={index} className="bg-card p-6 border-l-4 border-accent">
              <div className="flex items-center gap-3 mb-3">
                <AlertTriangle className="w-5 h-5 text-accent" />
                <h3 className="text-lg font-bold text-foreground">{friction.title}</h3>
              </div>
              <p className="text-muted-foreground">{friction.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HospitalReality;
