import React from 'react';
import { Radio, Target, Users } from 'lucide-react';

const needs = [
  {
    icon: Radio,
    title: "Right Signals at the Right Time",
    desc: "Not more data. Not more dashboards. The specific information that matters, delivered to the people who can act on it, when they can still make a difference."
  },
  {
    icon: Target,
    title: "Preemptive Actions",
    desc: "Clear protocols that trigger before problems escalate. Not reactive firefighting—proactive intervention based on early warning signs."
  },
  {
    icon: Users,
    title: "Leaders Who Empower Teams",
    desc: "Frontline staff authorized to act on what they see. No waiting for permission. No escalation delays. Distributed authority with clear accountability."
  }
];

const HospitalNeeds: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            What Hospitals Actually Need
          </h2>
          <p className="text-xl text-muted-foreground">
            Forget the vendor pitches. Here's what actually moves the needle.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {needs.map((need, index) => (
            <div key={index} className="bg-card p-8 md:p-10 border border-border">
              <need.icon className="w-12 h-12 text-accent mb-6" strokeWidth={1.5} />
              <h3 className="text-2xl font-bold text-foreground mb-4">{need.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{need.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HospitalNeeds;
