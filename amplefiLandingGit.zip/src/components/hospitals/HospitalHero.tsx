import React from 'react';

const HospitalHero: React.FC = () => {
  const scrollToSystem = () => {
    document.getElementById('agentic-system')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center bg-background text-foreground overflow-hidden">
      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 py-32 pt-40">
        <div className="max-w-3xl">
          <span className="inline-block text-sm font-semibold text-accent uppercase tracking-wider mb-6">
            Hospital Operations
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tight mb-8">
            Hospitals Don't Need More Tech. They Need Foresight.
          </h1>
          <p className="text-xl md:text-2xl text-accent mb-12 max-w-2xl leading-relaxed">
            We help hospitals see around corners, prevent predictable problems, and empower teams to act before the crisis hits.
          </p>
          <button 
            onClick={scrollToSystem}
            className="bg-primary text-primary-foreground px-8 py-4 text-lg font-semibold transition-colors"
          >
            Explore the Hospital Operating System
          </button>
        </div>
      </div>
    </section>
  );
};

export default HospitalHero;
