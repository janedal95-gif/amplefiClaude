import React from 'react';
import HomePage from './HomePage';

const AppLayout: React.FC = () => {
  return <HomePage />;
};

export default AppLayout;