import React from 'react';
import { Check } from 'lucide-react';

const differences = [
  "Not because you don’t care.",
  "Not because you aren’t skilled.",
  "But because most systems aren’t designed for how humans behave under pressure.",
  "You want a good, safe day — for your patients and for each other.",
  "In high-pressure environments, important signals are often missed.",
  "You show up to the shift carrying responsibility that doesn’t pause."
];

const DifferenceSection: React.FC = () => {
  const scrollToContact = () => {
    document.getElementById('footer')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-24 md:py-32 bg-card text-card-foreground">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 space-y-6">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight mb-6">
          Amplefi
        </h2>
        <p className="text-xl">
          Amplefi exists to support the people doing the work.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 pt-6">
          <button 
            onClick={scrollToContact}
            className="bg-primary text-primary-foreground px-10 py-5 text-lg font-semibold transition-colors"
          >
            Request a walkthrough
          </button>
          <button 
            onClick={scrollToContact}
            className="border-2 border-secondary text-secondary-foreground px-10 py-5 text-lg font-semibold transition-colors"
          >
            See how Amplefi works
          </button>
        </div>
      </div>
    </section>
  );
};

export default DifferenceSection;
