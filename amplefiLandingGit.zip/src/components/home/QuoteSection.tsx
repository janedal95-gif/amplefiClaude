import React from 'react';

const QuoteSection: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-5xl mx-auto px-6 lg:px-8 text-center">
        <blockquote className="text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground leading-tight mb-8">
          Failure is usually predictable — we just don’t listen.
        </blockquote>
        <p className="text-lg text-muted-foreground">
          Amplefi
        </p>
      </div>
    </section>
  );
};

export default QuoteSection;
