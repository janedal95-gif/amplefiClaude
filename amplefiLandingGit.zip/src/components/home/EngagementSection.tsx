import React from 'react';
import { Mic, Clock, Rocket } from 'lucide-react';

const engagements = [
  {
    icon: Mic,
    title: "Human behavior changes under pressure",
    duration: "",
    desc: "Amplefi exists to support the people doing the work.",
    cta: "Request a walkthrough"
  },
  {
    icon: Clock,
    title: "Intuition is data",
    duration: "",
    desc: "Experience matters",
    cta: "See how Amplefi works"
  },
  {
    icon: Rocket,
    title: "Teams perform better when awareness is shared",
    duration: "",
    desc: "Built to support the people who carry the shift.",
    cta: "Request a walkthrough"
  }
];

const EngagementSection: React.FC = () => {
  const scrollToContact = () => {
    document.getElementById('footer')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="engagement" className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-semibold text-foreground mb-6">
            We understand:
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Nurses and frontline care teams
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {engagements.map((eng, index) => (
            <div key={index} className="border-2 border-border p-8 md:p-10 hover:border-accent transition-colors group bg-card">
              <eng.icon className="w-12 h-12 text-accent mb-6" strokeWidth={1.5} />
              <span className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">{eng.duration}</span>
              <h3 className="text-2xl font-semibold text-foreground mt-2 mb-4">{eng.title}</h3>
              <p className="text-muted-foreground mb-8 leading-relaxed">{eng.desc}</p>
              <button 
                onClick={scrollToContact}
                className="text-accent font-semibold hover:underline"
              >
                {eng.cta} →
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EngagementSection;
