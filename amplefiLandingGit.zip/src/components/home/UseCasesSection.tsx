import React from 'react';
const UseCasesSection: React.FC = () => {
  return (
    <section id="choose-path" className="py-24 md:py-32 bg-gradient-to-b from-background via-background to-card">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-semibold text-foreground mb-6">
            Choose your path
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Two focused programs. One goal: operational control that holds under pressure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-8 bg-accent text-accent-foreground text-left rounded-lg shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)]">
            <h3 className="text-2xl font-semibold mb-4">Amplefi Health (Hospitals &amp; Health Systems)</h3>
            <p className="text-lg mb-6">
              For hospital operators who need to move from reactive firefighting to early intervention—before staff or patients are impacted.
            </p>
            <a
              href="https://amplefihealth.amplefiops.com/"
              className="inline-flex items-center justify-center bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold transition-colors rounded-full"
            >
              Go to Amplefi Health
            </a>
          </div>
          <div className="p-8 bg-accent text-accent-foreground text-left rounded-lg shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)]">
            <h3 className="text-2xl font-semibold mb-4">Office in a Box</h3>
            <p className="text-lg mb-6">
              For independent professionals and small businesses replacing reactive work with a clear, owner-controlled operating system.
            </p>
            <a
              href="https://officeinabox.amplefiops.com/"
              className="inline-flex items-center justify-center bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold transition-colors rounded-full"
            >
              Go to Office in a Box
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UseCasesSection;
