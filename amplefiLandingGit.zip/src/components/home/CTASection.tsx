import React from 'react';

const CTASection: React.FC = () => {
  const scrollToChoosePath = () => {
    document.getElementById('choose-path')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-24 md:py-32 bg-gradient-to-b from-card via-card to-background text-card-foreground">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-semibold leading-tight mb-8 text-card-foreground">
          Owner-controlled systems. Built with you.
        </h2>
        <p className="text-xl text-card-foreground mb-12 max-w-2xl mx-auto">
          Fixed-scope, guided programs that build practical systems you control.
        </p>
        <button 
          onClick={scrollToChoosePath}
          className="bg-primary text-primary-foreground px-10 py-5 text-lg font-semibold transition-colors rounded-full shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)]"
        >
          Choose your path
        </button>
      </div>
    </section>
  );
};

export default CTASection;
