import React from 'react';
const HeroSection: React.FC = () => {
  return (
    <section
      className="relative min-h-screen flex items-center bg-background text-foreground overflow-hidden"
      style={{
        backgroundImage: 'url(/amplefiHero.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-[linear-gradient(to_bottom,rgba(233,238,240,0.35),rgba(249,246,242,0)_140px)]" />
      <div className="absolute inset-0 bg-[#F9F6F2]/70" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-36 bg-gradient-to-b from-transparent to-[#F9F6F2] blur-2xl" />
      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 py-32 pt-40">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-semibold leading-[0.95] tracking-tight mb-8 text-foreground">
            Serious operations can’t stay reactive.
          </h1>
          <p className="text-xl md:text-2xl text-accent mb-12 max-w-2xl leading-relaxed">
            Amplefi replaces reactive operations with a calm, preemptive operating system—built with you and supported by usable AI.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="https://amplefihealth.amplefiops.com/"
              className="bg-primary text-primary-foreground px-8 py-4 text-lg font-semibold transition-colors rounded-full shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)] text-center"
            >
              Amplefi Health
            </a>
            <a
              href="https://officeinabox.amplefiops.com/"
              className="border-2 border-secondary text-accent px-8 py-4 text-lg font-semibold transition-colors rounded-full shadow-[0_12px_30px_-12px_rgba(0,0,0,0.5)] text-center"
            >
              Office in a Box
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
