import React from 'react';

const SocialProofSection: React.FC = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-card via-card to-background">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <p className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
          We build systems you own. We keep scope tight. We focus on execution over theory. We reduce vendor dependence.
        </p>
      </div>
    </section>
  );
};

export default SocialProofSection;
