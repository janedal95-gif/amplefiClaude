import React from 'react';
const WhatWeDoSection: React.FC = () => {
  return (
    <section id="methodology" className="py-24 md:py-32 bg-gradient-to-b from-background via-background to-card">
      <div className="max-w-5xl mx-auto px-6 lg:px-8">
        <div className="relative">
          <img
            src="/3Pillars.png"
            alt="Three Pillar Logic"
            className="w-full"
          />
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-[#F9F6F2] to-transparent" />
            <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-[#F9F6F2] to-transparent" />
            <div className="absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-[#F9F6F2] to-transparent" />
            <div className="absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-[#F9F6F2] to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhatWeDoSection;
