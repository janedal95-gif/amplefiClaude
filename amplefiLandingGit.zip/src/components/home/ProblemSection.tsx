import React from 'react';
import { AlertCircle } from 'lucide-react';

const ProblemSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-card via-card to-background">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 space-y-8">
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-semibold text-foreground leading-tight">
          From reactive operations to operational control
        </h2>
        <p className="text-xl text-muted-foreground">
          Before: Reactive operations. Problems surface too late. Decisions bottleneck at the top. Teams wait for direction. Leaders firefight instead of steer. After: Amplefi operations. Early signals show drift. Decisions move at the right level. Clear escalation replaces guesswork. Leaders stay ahead, not behind.
        </p>
      </div>
    </section>
  );
};

export default ProblemSection;
