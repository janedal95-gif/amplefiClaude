import React from 'react';
import { Building2, Scale, Boxes } from 'lucide-react';

const industries = [
  { icon: Building2, name: "Operating rhythm", desc: "A runnable operating cadence (not a deck)" },
  { icon: Scale, name: "Authority clarity", desc: "Clear escalation paths and decision rules" },
  { icon: Boxes, name: "Decision support", desc: "Practical AI support that reduces noise and surfaces signals" }
];

const IndustriesSection: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-4xl md:text-5xl font-semibold text-foreground mb-6">
            What you leave with
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl">
            You leave with a system you can run without us.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {industries.map((industry, index) => (
            <div 
              key={index}
              className="group border-2 border-border p-8 hover:border-accent transition-colors cursor-pointer"
            >
              <industry.icon className="w-10 h-10 text-muted-foreground group-hover:text-accent transition-colors mb-4" strokeWidth={1.5} />
              <h3 className="text-xl font-semibold text-foreground mb-2">{industry.name}</h3>
              <p className="text-muted-foreground">{industry.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IndustriesSection;
