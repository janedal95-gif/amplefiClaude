import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import logo from '../../amplefiLogoTransparent.png';

const Header: React.FC = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const scrollToChoosePath = () => {
    const section = document.getElementById('choose-path');
    section?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <Link to="/" className="flex items-center gap-3">
              <img src={logo} alt="Amplefi" className="h-8 w-auto" />
            </Link>
            
            <nav className="hidden md:flex items-center gap-8">
              <Link to="/" className={`text-sm font-medium transition-colors ${location.pathname === '/' ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                Home
              </Link>
              <Link to="/about" className={`text-sm font-medium transition-colors ${location.pathname === '/about' ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                About
              </Link>
              <Link to="/contact" className={`text-sm font-medium transition-colors ${location.pathname === '/contact' ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                Contact
              </Link>
              <button onClick={scrollToChoosePath} className="bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold transition-colors">
                Choose your path
              </button>
            </nav>

            <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2">
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden fixed inset-0 top-20 bg-background z-40">
            <nav className="flex flex-col p-6 gap-6">
              <Link to="/" onClick={() => setMenuOpen(false)} className="text-2xl font-semibold">Home</Link>
              <Link to="/about" onClick={() => setMenuOpen(false)} className="text-2xl font-semibold">About</Link>
              <Link to="/contact" onClick={() => setMenuOpen(false)} className="text-2xl font-semibold">Contact</Link>
              <button onClick={scrollToChoosePath} className="bg-primary text-primary-foreground px-6 py-4 text-lg font-semibold mt-4">
                Choose your path
              </button>
            </nav>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;
