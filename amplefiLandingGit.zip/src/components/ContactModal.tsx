import React, { useState } from 'react';
import { X } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      onClose();
      setSubmitted(false);
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-primary/60" onClick={onClose} />
      <div className="relative bg-card w-full max-w-lg p-8 md:p-10 text-foreground">
        <button onClick={onClose} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
          <X size={24} />
        </button>
        
        {submitted ? (
          <div className="text-center py-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">Amplefi</h3>
            <p className="text-muted-foreground">Amplefi exists to support the people doing the work.</p>
          </div>
        ) : (
          <>
            <h3 className="text-2xl font-bold text-foreground mb-2">Request a walkthrough</h3>
            <p className="text-muted-foreground mb-6">Amplefi exists to support the people doing the work.</p>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                placeholder="Your name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full border border-secondary px-4 py-3 focus:outline-none focus:border-accent bg-background text-foreground"
                required
              />
              <input
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full border border-secondary px-4 py-3 focus:outline-none focus:border-accent bg-background text-foreground"
                required
              />
              <input
                type="text"
                placeholder="Company"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
                className="w-full border border-secondary px-4 py-3 focus:outline-none focus:border-accent bg-background text-foreground"
              />
              <textarea
                placeholder="What's your biggest operational challenge?"
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                rows={4}
                className="w-full border border-secondary px-4 py-3 focus:outline-none focus:border-accent resize-none bg-background text-foreground"
              />
              <button type="submit" className="w-full bg-primary text-primary-foreground py-4 font-semibold transition-colors">
                Send Message
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default ContactModal;
