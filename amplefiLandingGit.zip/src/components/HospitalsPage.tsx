import React from 'react';
import Header from './Header';
import Footer from './Footer';
import HospitalHero from './hospitals/HospitalHero';
import HospitalReality from './hospitals/HospitalReality';
import HospitalNeeds from './hospitals/HospitalNeeds';
import AgenticSystem from './hospitals/AgenticSystem';
import HospitalStats from './hospitals/HospitalStats';
import AgentCapabilities from './hospitals/AgentCapabilities';
import MVPSection from './hospitals/MVPSection';
import ComparisonSection from './hospitals/ComparisonSection';
import HospitalCTA from './hospitals/HospitalCTA';

const HospitalsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HospitalHero />
        <HospitalReality />
        <HospitalNeeds />
        <AgenticSystem />
        <HospitalStats />
        <AgentCapabilities />
        <MVPSection />
        <ComparisonSection />
        <HospitalCTA />
      </main>
      <Footer />
    </div>
  );
};

export default HospitalsPage;
