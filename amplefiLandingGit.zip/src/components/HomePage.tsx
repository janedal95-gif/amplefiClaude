import React from 'react';
import Header from './Header';
import Footer from './Footer';
import HeroSection from './home/HeroSection';
import ProblemSection from './home/ProblemSection';
import WhatWeDoSection from './home/WhatWeDoSection';
import IndustriesSection from './home/IndustriesSection';
import UseCasesSection from './home/UseCasesSection';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <ProblemSection />
        <WhatWeDoSection />
        <IndustriesSection />
        <UseCasesSection />
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
