import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import logo from '../../amplefiLogoTransparent.png';

const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setEmail('');
    }
  };

  return (
    <footer id="footer" className="bg-primary text-black py-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-2">
            <div className="mb-4">
              <img src={logo} alt="Amplefi" className="h-10 w-auto" />
            </div>
            <p className="text-black text-lg mb-6 max-w-md">
              An operations company building owner-controlled systems that hold under pressure.
            </p>
            <form onSubmit={handleSubmit} className="flex gap-2">
              {submitted ? (
                <p className="text-black">We build real systems, not templates.</p>
              ) : (
                <>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your email"
                    className="bg-background border border-secondary px-4 py-3 text-foreground flex-1 focus:outline-none focus:border-accent"
                    required
                  />
                  <button type="submit" className="bg-primary px-6 py-3 font-semibold text-black transition-colors">
                    Connect
                  </button>
                </>
              )}
            </form>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-black">Navigate</h3>
            <ul className="space-y-3 text-black">
              <li><Link to="/" className="text-black hover:text-accent transition-colors">Home</Link></li>
              <li><a href="https://amplefihealth.amplefiops.com/" className="text-black hover:text-accent transition-colors">Hospitals</a></li>
              <li><a href="https://officeinabox.amplefiops.com/" className="text-black hover:text-accent transition-colors">Office in a Box</a></li>
              <li><Link to="/about" className="text-black hover:text-accent transition-colors">About</Link></li>
              <li><Link to="/contact" className="text-black hover:text-accent transition-colors">Contact</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4 text-black">Contact</h3>
            <ul className="space-y-3 text-black">
              <li><a href="mailto:hello@amplefi.com" className="text-black hover:text-accent transition-colors">hello@amplefi.com</a></li>
              <li className="text-black">Based in the US</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-black text-sm">&copy; {new Date().getFullYear()} Amplefi. All rights reserved.</p>
          <p className="text-black text-sm">Not software. Not consulting. Real systems.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
